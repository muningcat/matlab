addpath(genpath('/system'))
addpath(genpath('/components'));
addpath(genpath('/helpers'));
addpath(genpath('/views'));

implementor = Implementor();
implementor.start();