classdef Implementor

    properties
        main_view
    end
    
    methods
        function obj = Implementor()
            obj.main_view = MainView();
        end
    end
    
end