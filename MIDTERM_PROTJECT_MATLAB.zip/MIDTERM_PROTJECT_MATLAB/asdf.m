

% --- Executes just before MainView is made visible.
function MainView_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MainView (see VARARGIN)

% Choose default command line output for MainView
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MainView wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MainView_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

I = 0;

% --- Executes on button press in ButtonSave.
function ButtonSave_Callback(hObject, eventdata, handles)
    [filename, foldername] = uiputfile('Where do you want the file saved?');
    complete_name = fullfile(foldername, filename);
    imwrite(I, complete_name);


% --- Executes on button press in LoadButton.
function LoadButton_Callback(hObject, eventdata, handles)

    %handles.output = hObject;
    fn = uigetfile('*.jpg','select dicom file');
    I = imread(fn);
    imshow(I);
    %complete = strcat(pn,fn);
    %set(handles.edit1,'string',complete);
    %I = dicomread(complete);
    %imshow(I,[]);
    %guidata(hObject, handles);

    %s = uiopen('*.jpg; *.png');
    
    %fprintf('%s', s); 
    %myImage = imread('as.jpg');
    %set(handles.axes7,'Units','pixels');
    %resizePos = get(handles.axes7,'Position');
    %myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
    %axes(handles.axes7);
    %imshow(myImage);
    %set(handles.axes7,'Units','normalized');


% --- Executes on slider movement.
function BrightnessSlider_Callback(hObject, eventdata, handles)
    offset = get(hObject,'Value');
    I = I + offset;


% --- Executes during object creation, after setting all properties.
function BrightnessSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BrightnessSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in CropButton.
function CropButton_Callback(hObject, eventdata, handles)
% hObject    handle to CropButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in FlipButton.
function FlipButton_Callback(hObject, eventdata, handles)
% hObject    handle to FlipButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on ButtonSave and none of its controls.
function ButtonSave_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to ButtonSave (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
