classdef MainController
    
    properties
        current_I
    end
    
    methods(Static)
        function save()
            [filename, foldername] = uiputfile('Where do you want the file saved?');
            complete_name = fullfile(foldername, filename);
            imwrite(obj.current_I, complete_name);
        end
        
        function loaded_I = load()
            fn = uigetfile('*.jpg','select dicom file');
            obj.current_I = imread(fn);
            loaded_I = obj.current_I;
            
        end
        
    end
end