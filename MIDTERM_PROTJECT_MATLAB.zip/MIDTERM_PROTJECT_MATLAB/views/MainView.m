function varargout = MainView(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MainView_OpeningFcn, ...
                   'gui_OutputFcn',  @MainView_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


function MainView_OpeningFcn(hObject, eventdata, handles, varargin)

% Choose default command line output for MainView
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MainView wait for user response (see UIRESUME)
% uiwait(handles.figure1);


function varargout = MainView_OutputFcn(hObject, eventdata, handles) 

% Get default command line output from handles structure
varargout{1} = handles.output;

global main_controller;
main_controller = MainController();

function ButtonSave_Callback(hObject, eventdata, handles)
    global main_controller
    main_controller.save();
    


% --- Executes on button press in LoadButton.
function LoadButton_Callback(hObject, eventdata, handles)
    global main_controller
    imshow(main_controller.load());

    %handles.output = hObject;
   
    %complete = strcat(pn,fn);
    %set(handles.edit1,'string',complete);
    %I = dicomread(complete);
    %imshow(I,[]);
    %guidata(hObject, handles);

    %s = uiopen('*.jpg; *.png');
    
    %fprintf('%s', s); 
    %myImage = imread('as.jpg');
    %set(handles.axes7,'Units','pixels');
    %resizePos = get(handles.axes7,'Position');
    %myImage= imresize(myImage, [resizePos(3) resizePos(3)]);
    %axes(handles.axes7);
    %imshow(myImage);
    %set(handles.axes7,'Units','normalized');


% --- Executes on slider movement.
function BrightnessSlider_Callback(hObject, eventdata, handles)
    offset = get(hObject,'Value');
    I = I + offset;


% --- Executes during object creation, after setting all properties.
function BrightnessSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BrightnessSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in CropButton.
function CropButton_Callback(hObject, eventdata, handles)
% hObject    handle to CropButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in FlipButton.
function FlipButton_Callback(hObject, eventdata, handles)
% hObject    handle to FlipButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on ButtonSave and none of its controls.
function ButtonSave_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to ButtonSave (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
