I = imread('pic.jpg');
II = imresize(I, 0.8);
%I_II = imadd(I,II);
%imshow(I_II);

[X2,map2] = imread('pic.jpg');
subplot(1,2,1), subimage(X,map);
subplot(1,2,2), subimage(X2,map2);